//5. Write a C++ program to accept length and width of a rectangle. Calculate and display perimeter as well as area of a rectangle by using Inline function.


#include<iostream>

using namespace std;

inline void calculatePerimeterAndArea(float length, float width, float& perimeter, float& area) {
    perimeter = 2 * (length + width);
    area = length * width;
}

int main() {
    float length, width, perimeter, area;

    cout << "Enter length of rectangle: ";
    cin >> length;
    cout << "Enter width of rectangle: ";
    cin >> width;

    calculatePerimeterAndArea(length, width, perimeter, area);

    cout << "Perimeter of rectangle is " << perimeter << endl;
    cout << "Area of rectangle is " << area << endl;

    return 0;
}
