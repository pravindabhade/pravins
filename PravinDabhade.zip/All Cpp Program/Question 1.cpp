//1. Write a C++ program to subtract two integer numbers of two different classes using friend function.



#include <iostream>
using namespace std;

class Number2; // forward declaration

class Number1 {
private:
    int num1;
public:
    Number1(int n1) : num1(n1) {}
    friend int subtract(Number1 n1, Number2 n2);
};

class Number2 {
private:
    int num2;
public:
    Number2(int n2) : num2(n2) {}
    friend int subtract(Number1 n1, Number2 n2);
};

int subtract(Number1 n1, Number2 n2) {
    return n1.num1 - n2.num2;
}

int main() {
    int n1, n2;
    cout << "Enter first Number: ";
    cin >> n1;
    cout << "Enter second Number: ";
    cin >> n2;
    Number1 num1(n1);
    Number2 num2(n2);
    cout << "Subtraction result: " << subtract(num1, num2) << endl;
    return 0;
}



