//16. Create a C++ class for a student object with the following attributes�roll no, name, number of subjects, marks of subjects. Write member function for accepting marks and display all information of student along with total and Percentage. Display marklist with Use of�manipulators.


#include <iostream>
#include <iomanip>
using namespace std;

class Student {
private:
    int roll_no;
    string name;
    int num_subjects;
    int* marks;

public:
    Student(int r, string n, int num) {
        roll_no = r;
        name = n;
        num_subjects = num;
        marks = new int[num_subjects];
    }

    void accept_marks() {
        for (int i = 0; i < num_subjects; i++) {
            cout << "Enter marks for subject " << i + 1 << ": ";
            cin >> marks[i];
        }
    }

    void display_info() {
        cout << "Roll no: " << roll_no << endl;
        cout << "Name: " << name << endl;
        cout << "Number of subjects: " << num_subjects << endl;
        cout << "Marks: ";
        for (int i = 0; i < num_subjects; i++) {
            cout << marks[i] << " ";
        }
        cout << endl;

        int total_marks = 0;
        for (int i = 0; i < num_subjects; i++) {
            total_marks += marks[i];
        }
        double percentage = (double)total_marks / num_subjects;

        cout << "Total marks: " << total_marks << endl;
        cout << "Percentage: " << fixed << setprecision(2) << percentage << "%" << endl;
    }

    void display_marklist() {
        cout << "Roll no: " << setw(10) << "Name: " << setw(20);
        for (int i = 0; i < num_subjects; i++) {
            cout << "Subject " << i + 1 << setw(10);
        }
        cout << "Total" << endl;

        cout << roll_no << setw(10) << name << setw(20);
        int total_marks = 0;
        for (int i = 0; i < num_subjects; i++) {
            cout << marks[i] << setw(10);
            total_marks += marks[i];
        }
        cout << total_marks << endl;
    }

    ~Student() {
        delete[] marks;
    }
};

int main() {
    int roll_no, num_subjects;
    string name;

    cout << "Enter roll no: ";
    cin >> roll_no;

    cout << "Enter name: ";
    cin.ignore();
    getline(cin, name);

    cout << "Enter number of subjects: ";
    cin >> num_subjects;

    Student student(roll_no, name, num_subjects);
    student.accept_marks();

    cout << "\nStudent information:\n";
    student.display_info();

    cout << "\nMark list:\n";
    student.display_marklist();

    return 0;
}


