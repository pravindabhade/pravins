//2. Write a C++ program to read a text file and count number of Upper-case Alphabets, Lowercase Alphabets Digits and Spaces using File Handling



#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() {
    string filename;
    cout << "Enter the name of the input file: ";
    cin >> filename;

    ifstream input_file(filename);
    if (!input_file.is_open()) {
        cout << "Unable to open file " << filename << endl;
        return 1;
    }

    int upper_count = 0;
    int lower_count = 0;
    int digit_count = 0;
    int space_count = 0;
    char ch;

    while (input_file.get(ch)) {
        if (isupper(ch)) {
            upper_count++;
        } else if (islower(ch)) {
            lower_count++;
        } else if (isdigit(ch)) {
            digit_count++;
        } else if (isspace(ch)) {
            space_count++;
        }
    }

    input_file.close();

    string output_filename;
    cout << "Enter the name of the output file: ";
    cin >> output_filename;

    ofstream output_file(output_filename);
    if (!output_file.is_open()) {
        cout << "Unable to create output file " << output_filename << endl;
        return 1;
    }

    output_file << "Number of uppercase alphabets: " << upper_count << endl;
    output_file << "Number of lowercase alphabets: " << lower_count << endl;
    output_file << "Number of digits: " << digit_count << endl;
    output_file << "Number of spaces: " << space_count << endl;

    output_file.close();

    return 0;
}

