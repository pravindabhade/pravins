//13. Implement a class Complex which represents the Complex Number data type. Implement the following operations: 1. Constructor (including a default constructor which creates the complex number0+0i). 2. Overloaded operator+ to add two complex numbers. 


#include <iostream>

using namespace std;

class Complex {
private:
    double real;
    double imaginary;
public:
    Complex() {
        real = 0;
        imaginary = 0;
    }
    Complex(double r, double i) {
        real = r;
        imaginary = i;
    }
    Complex operator+(Complex const &obj) {
        Complex res;
        res.real = real + obj.real;
        res.imaginary = imaginary + obj.imaginary;
        return res;
    }
    void print() {
        cout << real << " + " << imaginary << "i" << endl;
    }
};

int main() {
    double r1, i1, r2, i2;
    cout << "Enter real and imaginary part of first complex number: ";
    cin >> r1 >> i1;
    cout << "Enter real and imaginary part of second complex number: ";
    cin >> r2 >> i2;

    Complex c1(r1, i1);
    Complex c2(r2, i2);
    Complex c3 = c1 + c2;

    cout << "Sum of two complex numbers: ";
    c3.print();

    return 0;
}


