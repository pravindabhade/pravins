/*6. Write a C++ program using function to count and display the number of lines not starting with 
   alphabet �A� in a text file.
*/


#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int countLinesNotStartingWithA(string fileName) {
    ifstream inputFile;
    inputFile.open(fileName);

    if (!inputFile) {
        cout << "Error opening file " << fileName << endl;
        return -1;
    }

    int count = 0;
    string line;
    while (getline(inputFile, line)) {
        if (line[0] != 'A' && line[0] != 'a') {
            count++;
        }
    }

    inputFile.close();
    return count;
}

int main() {
    string fileName;
    cout << "Enter file name: ";
    cin >> fileName;

    int count = countLinesNotStartingWithA(fileName);

    if (count == -1) {
        return 1;
    }

    cout << "Number of lines not starting with 'A': " << count << endl;

    return 0;
}
