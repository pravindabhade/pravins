//8. Write a C++ program to swap two integer values and two float values by using function template.


#include <iostream>
using namespace std;

template<typename T>
void swap_values(T &a, T &b) {
    T temp = a;
    a = b;
    b = temp;
}

int main() {
    int int1, int2;
    float float1, float2;

    cout << "Enter two integer values: ";
    cin >> int1 >> int2;

    cout << "Enter two float values: ";
    cin >> float1 >> float2;

    cout << "Before swapping:" << endl;
    cout << "Integer values: " << int1 << " " << int2 << endl;
    cout << "Float values: " << float1 << " " << float2 << endl;

    swap_values(int1, int2);
    swap_values(float1, float2);

    cout << "After swapping:" << endl;
    cout << "Integer values: " << int1 << " " << int2 << endl;
    cout << "Float values: " << float1 << " " << float2 << endl;

    return 0;
}



