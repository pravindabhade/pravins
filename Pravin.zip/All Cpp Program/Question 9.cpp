//9. Write a C++ program to calculate area of cone, sphere and circle by using function overloading.


#include <iostream>
#include <cmath>

using namespace std;

const double PI = 3.14159265;

double area(double radius) {
    return PI * pow(radius, 2);
}

double area(double radius, double height) {
    double slantHeight = sqrt(pow(radius, 2) + pow(height, 2));
    return PI * radius * slantHeight + PI * pow(radius, 2);
}

double area(double radius, double height, double sideLength) {
    double baseArea = PI * pow(radius, 2);
    double lateralArea = PI * radius * sideLength;
    double totalArea = baseArea + lateralArea;
    return totalArea;
}

int main() {
    double radius, height, sideLength;

    cout << "Enter radius of circle: ";
    cin >> radius;
    cout << "Area of circle: " << area(radius) << endl;

    cout << "Enter radius and height of cone: ";
    cin >> radius >> height;
    cout << "Area of cone: " << area(radius, height) << endl;

    cout << "Enter radius, height, and side length of sphere: ";
    cin >> radius >> height >> sideLength;
    cout << "Area of sphere: " << area(radius, height, sideLength) << endl;

    return 0;
}




