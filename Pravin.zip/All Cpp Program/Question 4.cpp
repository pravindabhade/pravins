
//4. Write a C++ program to find area and volume of cylinder using Inline function.


#include <iostream>
using namespace std;

inline double cylinderArea(double radius, double height) {
    return 2 * 3.14 * radius * height + 2 * 3.14 * radius * radius;
}

inline double cylinderVolume(double radius, double height) {
    return 3.14 * radius * radius * height;
}

int main() {
    double radius, height;
    cout << "Enter the radius of the cylinder: ";
    cin >> radius;
    cout << "Enter the height of the cylinder: ";
    cin >> height;

    double area = cylinderArea(radius, height);
    double volume = cylinderVolume(radius, height);

    cout << "The area of the cylinder is: " << area << endl;
    cout << "The volume of the cylinder is: " << volume << endl;

    return 0;
}


