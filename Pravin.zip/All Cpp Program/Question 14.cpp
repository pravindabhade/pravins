
//14. Write a C++ program create a calculator for an arithmetic operator (+, -, *, /). The program should take two operands from user and performs the operation on those two operands depending upon the operator entered by user. Use a switch statement to select the operation.
 

#include <iostream>
using namespace std;

int main() {
    float operand1, operand2;
    char op;

    cout << "Enter operator (+, -, *, /): ";
    cin >> op;

    cout << "Enter Frist Number: ";
    cin >> operand1 ;
    cout << "Enter Second Number: ";
	cin>> operand2;

    switch (op) {
        case '+':
            cout << "Result: " << operand1 + operand2 << endl;
            break;
        case '-':
            cout << "Result: " << operand1 - operand2 << endl;
            break;
        case '*':
            cout << "Result: " << operand1 * operand2 << endl;
            break;
        case '/':
            if (operand2 == 0) {
                cout << "Error: division by zero" << endl;
            } else {
                cout << "Result: " << operand1 / operand2 << endl;
            }
            break;
        default:
            cout << "Error: invalid operator" << endl;
    }

    return 0;
}



