//11. Write a C++ program to create a class Student which contains data members as Roll_Number, Stud_Name, Percentage. Write member functions to accept Student information. Display all details of student along with a class obtained depending on percentage. (Use array of objects).


#include <iostream>
#include <string>
using namespace std;

class Student {
    private:
        int Roll_Number;
        string Stud_Name;
        float Percentage;
    public:
        void accept_student();
        void display_student();
        string get_class();
};

void Student::accept_student() {
    cout << "Enter Roll Number: ";
    cin >> Roll_Number;
    cout << "Enter Student Name: ";
    cin.ignore();
    getline(cin, Stud_Name);
    cout << "Enter Percentage: ";
    cin >> Percentage;
}

void Student::display_student() {
    cout << "Roll Number: " << Roll_Number << endl;
    cout << "Student Name: " << Stud_Name << endl;
    cout << "Percentage: " << Percentage << "%" << endl;
}

string Student::get_class() {
    if (Percentage >= 90) {
        return "First Class with Distinction";
    } else if (Percentage >= 75) {
        return "First Class";
    } else if (Percentage >= 60) {
        return "Second Class";
    } else if (Percentage >= 50) {
        return "Pass Class";
    } else {
        return "Fail";
    }
}

int main() {
    const int num_students = 3;
    Student students[num_students];

    for (int i = 0; i < num_students; i++) {
        cout << "Enter details of student " << i+1 << ":" << endl;
        students[i].accept_student();
        cout << endl;
    }

    for (int i = 0; i < num_students; i++) {
        cout << "Details of student " << i+1 << ":" << endl;
        students[i].display_student();
        cout << "Class Obtained: " << students[i].get_class() << endl;
        cout << endl;
    }

    return 0;
}




