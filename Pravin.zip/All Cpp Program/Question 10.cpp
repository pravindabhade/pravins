//10. Write a C++ program to create a class which contains two data members. Write member functions to accept display and swap two entered numbers using call by reference.

#include <iostream>

using namespace std;

class Numbers {
    private:
        int num1, num2;

    public:
        void accept() {
            cout << "Enter two numbers: ";
            cin >> num1 >> num2;
        }

        void display() {
            cout << "Num1 = " << num1 << ", Num2 = " << num2 << endl;
        }

        void swap() {
            int temp = num1;
            num1 = num2;
            num2 = temp;
        }
};

int main() {
    Numbers n;

    n.accept();
    cout << "Before swapping:" << endl;
    n.display();
    n.swap();
    cout << "After swapping:" << endl;
    n.display();

    return 0;
}
