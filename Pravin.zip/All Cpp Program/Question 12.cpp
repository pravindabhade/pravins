//12. Write a C++ program to create a class Item with data members Item_Code, Item_Name, Item_Price. Write member functions to accept and display Item information also display number of objects created for a class. (Use Static data member and Static member function).



#include <iostream>
#include <string>
using namespace std;

class Item {
    private:
        int Item_Code;
        string Item_Name;
        float Item_Price;
        static int count;
    public:
        void accept_item();
        void display_item();
        static int get_count();
};

int Item::count = 0;

void Item::accept_item() {
    cout << "Enter item code: ";
    cin >> Item_Code;
    cout << "Enter item name: ";
    cin.ignore();
    getline(cin, Item_Name);
    cout << "Enter item price: ";
    cin >> Item_Price;
    count++;
}

void Item::display_item() {
    cout << "Item Code: " << Item_Code << endl;
    cout << "Item Name: " << Item_Name << endl;
    cout << "Item Price: " << Item_Price << endl;
}

int Item::get_count() {
    return count;
}

int main() {
    Item item1, item2, item3;
    item1.accept_item();
    item2.accept_item();
    item3.accept_item();

    cout << "Item 1 Details: " << endl;
    item1.display_item();
    cout << endl;

    cout << "Item 2 Details: " << endl;
    item2.display_item();
    cout << endl;

    cout << "Item 3 Details: " << endl;
    item3.display_item();
    cout << endl;

    cout << "Number of objects created: " << Item::get_count() << endl;
    return 0;
}


