//3. Write a C++ program to overload function volume and find volume of cube, cylinder and sphere.  


#include <iostream>
using namespace std;

// Function to find the volume of a cube
double volume(double side)
{
    return side * side * side;
}

// Function to find the volume of a cylinder
double volume(double radius, double height)
{
    return 3.14 * radius * radius * height;
}

// Function to find the volume of a sphere
double Volume(double radius)
{
    return (4.0 / 3.0) * 3.14 * radius * radius * radius;
}

int main()
{
    double s, r, h;

    // Input for cube
    cout << "Enter the length of a side of the cube: ";
    cin >> s;
    cout << "The volume of the cube is " << volume(s) << endl;

    // Input for cylinder
    cout << "Enter the radius of the cylinder: ";
    cin >> r;
    cout << "Enter the height of the cylinder: ";
    cin >> h;
    cout << "The volume of the cylinder is " << volume(r, h) << endl;

    // Input for sphere
    cout << "Enter the radius of the sphere: ";
    cin >> r;
    cout << "The volume of the sphere is " << Volume(r) << endl;

    return 0;
}
